<?php

/**
 * Plugin Name: Spectre Icons
 * Description: Modern SVG icon library integration for Elementor.
 * Version: 1.0.0
 * Author: PHC Devworks
 */

if (! defined('ABSPATH')) {
	exit;
}

/**
 * ------------------------------------------------------------
 *  CONSTANTS
 * ------------------------------------------------------------
 */
define('SPECTRE_ICONS_VERSION', '1.0.0');
define('SPECTRE_ICONS_PATH', plugin_dir_path(__FILE__));
define('SPECTRE_ICONS_URL', plugin_dir_url(__FILE__));

/**
 * ------------------------------------------------------------
 *  AUTOLOAD / INCLUDE FILES
 * ------------------------------------------------------------
 */
require_once SPECTRE_ICONS_PATH . 'includes/elementor/class-spectre-icons-elementor-library-manager.php';
require_once SPECTRE_ICONS_PATH . 'includes/elementor/class-spectre-icons-elementor-manifest-renderer.php';
require_once SPECTRE_ICONS_PATH . 'includes/elementor/class-spectre-icons-elementor-settings.php';

require_once SPECTRE_ICONS_PATH . 'includes/class-spectre-icons-svg-sanitizer.php';

require_once SPECTRE_ICONS_PATH . 'includes/elementor/icon-libraries.php';
require_once SPECTRE_ICONS_PATH . 'includes/elementor/integration-hooks.php';

/**
 * ------------------------------------------------------------
 *  PLUGIN INIT
 * ------------------------------------------------------------
 *
 * Handles loading Elementor integrations ONLY after Elementor loads.
 */
add_action('plugins_loaded', function () {

	// Fail quietly if Elementor is not active.
	if (! did_action('elementor/loaded')) {
		return;
	}

	// Integration hooks handle:
	//  - Settings
	//  - Library Manager
	//  - Manifest Renderer
	//  - Tabs registration
	//  - Editor enqueue
	//  - Manifest check notice
	spectre_icons_elementor_bootstrap();
});
