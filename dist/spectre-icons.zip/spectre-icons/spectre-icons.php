<?php
/**
 * Plugin Name: Spectre Icons
 * Plugin URI: https://github.com/phcdevworks/spectre-icons
 * Description: Spectre Icons brings bundled and uploaded SVG icon libraries directly into WordPress builders, delivering a unified, performance-focused icon system.
 * Version: 1.3.1
 * Author: PHCDevworks
 * Author URI: https://phcdevworks.com/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * SPDX-License-Identifier: GPL-2.0-or-later
 * Text Domain: spectre-icons
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Tested up to: 7.0
 *
 * @package SpectreIcons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PHP version check.
 */
if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	add_action(
		'admin_notices',
		function () {
			echo '<div class="notice notice-error"><p>';
			echo esc_html__( 'Spectre Icons requires PHP 7.4 or higher to function. Please contact your hosting provider to upgrade PHP.', 'spectre-icons' );
			echo '</p></div>';
		}
	);
	return;
}

define( 'SPECTRE_ICONS_VERSION', '1.3.1' );
define( 'SPECTRE_ICONS_PATH', plugin_dir_path( __FILE__ ) );
define( 'SPECTRE_ICONS_URL', plugin_dir_url( __FILE__ ) );

$spectre_icons_includes = array(
	// Core — builder-agnostic, no page-builder dependencies.
	'includes/class-spectre-icons-svg-sanitizer.php',
	'includes/core/class-spectre-icons-manifest-registry.php',
	'includes/core/class-spectre-icons-icon-renderer.php',
	'includes/core/manifest-helpers.php',
	'includes/core/class-spectre-icons-user-library-manager.php',

	// Admin — builder-agnostic.
	'includes/admin/class-spectre-icons-upload-page.php',

	// Elementor integration — depends on core.
	'includes/elementor/class-spectre-icons-elementor-settings.php',
	'includes/elementor/class-spectre-icons-elementor-library-adapter.php',
	'includes/elementor/icon-libraries.php',
	'includes/elementor/integration-hooks.php',
);

foreach ( $spectre_icons_includes as $spectre_icons_file ) {
	require_once SPECTRE_ICONS_PATH . $spectre_icons_file;
}

Spectre_Icons_User_Library_Manager::init();
Spectre_Icons_Upload_Page::init();
